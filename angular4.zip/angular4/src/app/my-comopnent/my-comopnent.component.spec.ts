import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyComopnentComponent } from './my-comopnent.component';

describe('MyComopnentComponent', () => {
  let component: MyComopnentComponent;
  let fixture: ComponentFixture<MyComopnentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyComopnentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyComopnentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
