import { Component } from '@angular/core';
import {FormGroup,FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

form ;
ngOnInit() {
  
  this.form =  new FormGroup({

      firstname : new FormControl("",Validators.required),
      lastname: new FormControl(""),
      language : new FormControl(""),
  
});
}



  onSubmit =function(user){
    console.log(user)


  }

arr=[3,2,7,8,9];
 myname="Ankit";
 day = new Date(1989,2,20);
  itemlist=["Angular4","react","Angular2"];
  newitem ="";
  pushitem = function(){
    console.log(this.newitem);
   if(this.newitem !="" ){
      this.itemlist.push(this.newitem);
      this.newitem="";
   }

  }

  removeItem = function(index){
   this.itemlist.splice(index,1);
  }

}
/*
  title = 'app start';
  obj={
   id:"1",
   name:"ankit"

  }

  arrylist=["aaaaa","bbbbb","cccc"];
  isTrue=false;
  myname="ankit";*/