import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-comopnent',
  templateUrl: './my-comopnent.component.html',
  styleUrls: ['./my-comopnent.component.css']
})
export class MyComopnentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
